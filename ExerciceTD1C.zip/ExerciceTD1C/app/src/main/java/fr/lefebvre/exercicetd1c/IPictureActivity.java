package fr.lefebvre.exercicetd1c;

public interface IPictureActivity {
    int REQUEST_CAMERA = 100;
}
