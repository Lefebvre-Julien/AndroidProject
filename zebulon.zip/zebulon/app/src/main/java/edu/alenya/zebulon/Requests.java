package edu.alenya.zebulon;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Parcelable;
import android.widget.TextView;

import java.io.Serializable;

public class Requests extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_requests);

        TextView txtMessage = findViewById(R.id.TxtViewMessage);

        String name = getIntent().getStringExtra("name");
        zebulonline zebulon = (zebulonline) getIntent().getSerializableExtra("zebulon");

        txtMessage.setText(String.format("%s, %s", name, zebulon.getToken()));
    }
}