package com.volpemaxime.application;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

public class test2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test2);

       /* Button button = findViewById(R.id.button2);
        button.setOnClickListener(click->{
            Intent intent = new Intent(test2.this, MainActivity.class);
            test2.this.startActivity(intent);
        });*/
    }
}