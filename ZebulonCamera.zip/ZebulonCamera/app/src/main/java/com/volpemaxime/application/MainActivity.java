package com.volpemaxime.application;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

public class MainActivity extends AppCompatActivity implements IPictureActivity {

    private Bitmap picture;
    private PictureFragment pictureFragment;

    //Au moment de la création ->
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Creer un fragment pour qu'il démarre bien avec au demarrage
        pictureFragment = (PictureFragment) getSupportFragmentManager().findFragmentById(R.id.fragmentPicture);
        if(pictureFragment == null){
           pictureFragment = new PictureFragment();
            FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
            transaction.replace(R.id.fragmentPicture, pictureFragment);
            transaction.addToBackStack(null);

        }



    }

    //Autorisation
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int [] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case REQUEST_CAMERA: {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Toast toast = Toast.makeText(getApplicationContext(), "CAMERA authorization granted", Toast.LENGTH_LONG);
                    toast.show();
                    pictureFragment.takePicture();

                } else {
                    Toast toast = Toast.makeText(getApplicationContext(), "CAMERA authorization Not granted", Toast.LENGTH_LONG);
                    toast.show();
                }
            }
            break;
        }
    }
    //Récupérer et MAJ photo
    @Override
    protected void onActivityResult(int requesCode, int resultCode, Intent data) {
        super.onActivityResult(requesCode, resultCode, data);
        if(requesCode == REQUEST_CAMERA){
            if(resultCode == RESULT_OK){
                //MAJ image bitmap
                picture = (Bitmap) data.getExtras().get("data");
                pictureFragment.setImage(picture);
            }else if(requesCode == RESULT_CANCELED){
                Toast toast = Toast.makeText(getApplicationContext(), "picture cancelled", Toast.LENGTH_LONG);
                toast.show();
            }else{
                Toast toast = Toast.makeText(getApplicationContext(), "action failed", Toast.LENGTH_LONG);
                toast.show();
            }
        }
    }
}