package com.volpemaxime.application;

public interface IPictureActivity {
    int REQUEST_CAMERA = 100;
}
