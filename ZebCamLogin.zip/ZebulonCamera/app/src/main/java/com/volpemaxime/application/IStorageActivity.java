package com.volpemaxime.application;

import android.graphics.Bitmap;

public interface IStorageActivity {
    int REQUEST_MEDIA_READ = 1000;       //Lecture partie de stockage
    int REQUEST_MEDIA_WRITE = 1001; //Ecriture partie de stockage
    void onPictureLoad(Bitmap bitmap); //demande au fragment de mettre à jour l'image
    Bitmap getPictureToSave();  //S'occupe de quelle image je veux qu'il sauvegarde

}
