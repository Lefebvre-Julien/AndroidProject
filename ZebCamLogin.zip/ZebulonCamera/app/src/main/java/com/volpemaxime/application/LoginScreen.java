package com.volpemaxime.application;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import java.io.Serializable;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicReference;

public class LoginScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        Button btnSend = findViewById(R.id.BtnSend);
        EditText UserLog = findViewById(R.id.UserLogin);
        EditText UserPass = findViewById(R.id.USerPassword);
        AtomicReference<Boolean> isLogged = new AtomicReference<>(false);

        btnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                zebulonline zebulon = new zebulonline(UserLog.getText().toString(),
                        UserPass.getText().toString(), "https://zebulon-rest-api.vercel.app/",
                        getApplicationContext().getDataDir());
                CountDownLatch latch = new CountDownLatch(1);
                ExecutorService executor = Executors.newSingleThreadExecutor();
                executor.submit(() -> {
                    try {
                        isLogged.set(zebulon.login());
                        latch.countDown();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                });

                try {
                    latch.await();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                executor.shutdown();

                if(isLogged.get()) {
                    Intent intent = new Intent(LoginScreen.this, SecondActivity.class);
                    intent.putExtra("name", zebulon.getName());
                    // Pass the zebulon object to the next activity
                    intent.putExtra("zebulon", (Serializable) zebulon);

                    startActivity(intent);
                }
            }
        });
    }
}