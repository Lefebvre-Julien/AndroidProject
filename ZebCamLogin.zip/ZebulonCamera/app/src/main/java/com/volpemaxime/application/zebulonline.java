package com.volpemaxime.application;

import androidx.annotation.NonNull;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Serializable;
import java.net.HttpURLConnection;
import java.net.URL;

public class zebulonline implements Serializable {
    private final String name;
    private final String pwd;
    private String token;
    private final String url;
    private final Object appCtx;

    /**
     * Basic Zebulon constructor
     * @param name  User login
     * @param pwd  User password
     * @param url Zebulon API server URL
     * @param appContext Application context (getApplicationContext().getDataDir())
     */
    public zebulonline(String name, String pwd, String url, Object appContext) {
        this.name = name;
        this.pwd = pwd;
        this.url = url;
        this.appCtx = appContext;
    }

    /**
     * Log the user into the application
     * @return true if the login was successful, false otherwise
     */
    public boolean login() {
        try {
            // API link
            URL url = new URL(this.url + "/login/" + this.name + "/" + this.pwd);

            // Create basic connection to the API
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();

            // Send HTTP GET header request to fetch JSON
            conn.setRequestMethod("GET");
            conn.connect();

            // Fetch JSON and parse it
            InputStream inputStream = conn.getInputStream();
            InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
            BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
            StringBuilder stringBuilder = new StringBuilder();
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                stringBuilder.append(line);
            }

            // Write the token to a file
            String json = stringBuilder.toString();
            this.token = new JSONArray(json).getJSONObject(0).getString("token");
            if (!writeToJson(json)) {
                return false;
            }

            // Validate the token
            JSONArray jsonArray = new JSONArray(json);
            if (!validateToken(jsonArray.getJSONObject(0).getString("token"))) {
                return false;
            }

            // Close connection
            conn.disconnect();

            System.out.println("ZebulOnline: Login successful");
            return true;
        } catch (IOException | JSONException e) {
            e.printStackTrace();
        }

        return false;
    }

    /**
     * Create a file to store the information about the user
     * @param json The JSON string to write to the file
     * @return true if the file was created successfully, false otherwise
     */
    public boolean writeToJson(@NonNull String json) {
        try {
            // Store the result
            String token = json.toString();
            JSONArray jsonArray = new JSONArray(json);
            JSONObject jsonObject = jsonArray.getJSONObject(0);

            // Get the token and output it to a local json file
            File file = new File(appCtx.toString(), "token.json");
            FileWriter fileWriter = new FileWriter(file);
            BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
            bufferedWriter.write(jsonObject.toString());
            bufferedWriter.close();
            return true;
        } catch (IOException | JSONException e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Validate the token
     *
     * @param token The token to validate
     * @return true if the token is valid, false otherwise
     */
    public boolean validateToken(String token)  {
        try {
            URL url = new URL(this.url + "/validate/" + token);
            HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.setRequestMethod("GET");
            urlConnection.connect();
            InputStream in = urlConnection.getInputStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(in));
            StringBuilder result = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                result.append(line);
            }
            return result.toString().equals("true");
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean uploadImage(String image) {
        try {
            URL url = new URL(this.url + "/upload/" + this.token);
            HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.setRequestMethod("GET");
            urlConnection.connect();
            InputStream in = urlConnection.getInputStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(in));
            StringBuilder result = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                result.append(line);
            }
            return result.toString().equals("true");
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public String getName() {
        return name;
    }

    public String getPwd() {
        return pwd;
    }

    public String getUrl() {
        return url;
    }

    public String getToken() {
        return token;
    }

    public Object getApp() {
        return appCtx;
    }
}
