package com.volpemaxime.application;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

public class SecondActivity extends AppCompatActivity implements IPictureActivity, IStorageActivity {

    private Bitmap picture;
    private PictureFragment pictureFragment;
    private StorageFragment storageFragment;

    //Au moment de la création ->
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Creer un fragment pour qu'il démarre bien avec au demarrage PictureFragment
        pictureFragment = (PictureFragment) getSupportFragmentManager().findFragmentById(R.id.fragmentPicture);
        if(pictureFragment == null){
           pictureFragment = new PictureFragment();
            FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
            transaction.replace(R.id.fragmentPicture, pictureFragment);
            transaction.addToBackStack(null);

        }

        //Creer un fragment pour qu'il démarre bien avec au demarrage StorageFragment
        storageFragment = (StorageFragment) getSupportFragmentManager().findFragmentById(R.id.fragmentStorage);
        if(storageFragment == null){
            storageFragment = new StorageFragment(this);
            FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
            transaction.replace(R.id.fragmentStorage, storageFragment);
            transaction.addToBackStack(null);

        }
    }

    //Autorisation
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int [] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case REQUEST_CAMERA: {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Toast toast = Toast.makeText(getApplicationContext(), "CAMERA authorization granted", Toast.LENGTH_LONG);
                    toast.show();
                    pictureFragment.takePicture();
                    //storageFragment.setEnableSaveButton();

                } else {
                    Toast toast = Toast.makeText(getApplicationContext(), "CAMERA authorization Not granted", Toast.LENGTH_LONG);
                    toast.show();
                }
            }break;
            case REQUEST_MEDIA_WRITE: {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    storageFragment.saveToInternalStorage(picture);
                    Toast toast = Toast.makeText(getApplicationContext(), "WRITE permission granted", Toast.LENGTH_LONG);
                    toast.show();


                } else {
                    Toast toast = Toast.makeText(getApplicationContext(), "WRITE permission Not granted", Toast.LENGTH_LONG);
                    toast.show();
                }
            } break;
            case REQUEST_MEDIA_READ: {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    Toast toast = Toast.makeText(getApplicationContext(), "READ permission granted", Toast.LENGTH_LONG);
                    toast.show();


                } else {
                    Toast toast = Toast.makeText(getApplicationContext(), "READ permission Not granted", Toast.LENGTH_LONG);
                    toast.show();
                }
            } break;
        }
    }

    //Récupérer et MAJ photo
    @Override
    protected void onActivityResult(int requesCode, int resultCode, Intent data) {
        super.onActivityResult(requesCode, resultCode, data);
        if(requesCode == REQUEST_CAMERA){
            if(resultCode == RESULT_OK){
                //MAJ image bitmap
                picture = (Bitmap) data.getExtras().get("data");
                pictureFragment.setImage(picture);
                storageFragment.setEnableSaveButton();

            }else if(requesCode == RESULT_CANCELED){
                Toast toast = Toast.makeText(getApplicationContext(), "picture cancelled", Toast.LENGTH_LONG);
                toast.show();
            }else{
                Toast toast = Toast.makeText(getApplicationContext(), "action failed", Toast.LENGTH_LONG);
                toast.show();
            }
        }
    }

    @Override
    public void onPictureLoad(Bitmap bitmap) {
    pictureFragment.setImage(bitmap); //Remplacement image -> nouveau bitmap
    }

    @Override
    public Bitmap getPictureToSave() {
        return picture; //Sauvegarde de picture
    }
}